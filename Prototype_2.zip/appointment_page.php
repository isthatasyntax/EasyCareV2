<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>

    <link rel="stylesheet" type="text/css" href="css/header.css">
    <link rel="stylesheet" type="text/css" href="css/footer.css">
    <link rel="stylesheet" type="text/css" href="css/body.css">
    <link rel="stylesheet" type="text/css" href="css/images.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet"
        class="roboto-slab-font">
    <link rel="stylesheet" href="pagedesign.css">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
    crossorigin="anonymous">

    
</head>

<body>

    <!--Navigation Bar-->
    <div class="topnav">
        <a href="carer_page.php">Carers</a>
        <a href="patient_page.php">Patients</a>
        <a href="appointment_page.php">Appointments</a>
        <a href="approval_page.php">Absences</a>
        <a href="index.php">Sign out</a>
    </div>
 
    <!-- This is displaying the carer information -->
    <?php
        include 'appointment_table.php';
    ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <?php
                // Display table headers
                foreach($info as $val){
                    echo "<th>".$val->name."</th>";
                }
                ?>
                <!-- Add an extra column for the button -->
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>

        <tbody>
            <?php
                while($row = mysqli_fetch_assoc($result)){
                    echo "<tr>";
                    foreach($row as $val){
                        // Display table data
                        print "<td>". $val. "</td>";
                    }
                    // Add a button in the last column of each row
                    echo "<td><a href='aptdata.html'><button class='btn border border-dark' >Edit</button></a></td>";
                    echo "<td><a href=''><button class='btn border border-dark' >Delete</button></a></td>";
                    echo "</tr>";
                } 
            ?>
        </tbody>
    </table>

    <!--Footer-->
    <footer>
        <div class="footer-content-container">
            <img class="logo" src="logo.png" alt="Easy Care" title="Logo"><br>
            <p>Contact Us:</p>
            <p>Email: EasyCare@gmail.co.uk | Phone: +44 20 1234 5678</p>
            <p>&copy; 2024. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>