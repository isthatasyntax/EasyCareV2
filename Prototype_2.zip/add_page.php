<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Form</title>
</head>
<body>
    
    <h1>Add Carer</h1>

    <div class="">
        <div class="">
                <form action="add_button.php" method="POST">
                    
                    <div class="">
                        <label for="name"></label>
                        <input type="text" class="" name="fname" id="name" placeholder="Full Name">
                    </div>
                    
                    <br>

                    <div class="">
                        <label for="dbs_num"></label>
                        <input type="text" class="" name="dbs" id="dbs_num" placeholder="DBS Number">
                    </div>
                    
                    <br>

                    <div class="">
                        <label for="phonenum"></label>
                        <input type="text" class="" name="pnum" id="phonenum" placeholder="Phone Number">
                    </div>

                    <br>

                    <div class="">
                        <label for="uname"></label>
                        <input type="text" class="" name="username" id="uname" placeholder="Username">
                    </div>
                    
                    <br>

                    <div class="">
                        <label for="password"></label>
                        <input type="text" class="" name="pword" id="password" placeholder="Password">
                    </div>
                    
                    <br>

                    <div class="">
                        <label for="emergencynum"></label>
                        <input type="text" class="" name="enum" id="emergencynum" placeholder="Emergency Number">
                    </div>

                    <br>

                    <div class="">
                        <label for="email"></label>
                        <input type="text" class="" name="mail" id="email" placeholder="Email Address">
                    </div>

                    <br>

                    <input type="submit" name="submit" id="sub" value="Submit">
                </form>
        </div>
    </div>


            

</body>
</html>