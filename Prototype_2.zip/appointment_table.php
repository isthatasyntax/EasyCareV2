<?php

    // Connect to server/database
    include("connection.php");

    $sql = "SELECT * FROM appointment_details ORDER BY Date";
    $result = $conn -> query ($sql);
    $info = $result ->fetch_fields();  

?>