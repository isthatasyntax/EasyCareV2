<?php
session_start();

include('connection.php');
    
if (isset($_POST['submit'])) {
    $username = $_POST['user'];
    $password = $_POST['pass'];

    if ($username === 'admin' && $password === 'admin') {
        // Redirect to carer_page.php if username and password are admin
        header("Location: carer_page.php");
        exit();
    }

    $sql = "SELECT * FROM carer_details WHERE username = '$username' AND password = '$password'";  
    $result = mysqli_query($conn, $sql);  
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
    $count = mysqli_num_rows($result);  
        
    if ($result->num_rows > 0) {
        
        $stmt = $conn->prepare("SELECT Name, Email, DBS_number FROM carer_details where username='$username'");
        $stmt->execute();
        $stmt_result = $stmt->get_result();

        if ($stmt_result->num_rows > 0) {
            $row = $stmt_result->fetch_assoc();
            $name = $row['Name'];
            $dbsno = $row['DBS_number'];
            $email = $row['Email'];

            $_SESSION['name'] = $name;
        }

        // Redirect to home_page_4.html if username and password are correct
        header("Location: home_page_4.html");
        exit();
    } else {
        // Redirect back to index.php if username and password are incorrect
        header("Location: index.php");
        exit();
    }    
} 
?>
