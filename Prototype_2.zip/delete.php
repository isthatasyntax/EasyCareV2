<?php
    include("connection.php");

    if (isset($_GET["id"])) { 
        $id = $_GET["id"];
    
    $sql = "DELETE FROM carer_details WHERE id=$id";
    $conn->query($sql);
    }

    header("Location: carer_page.php");
    exit;
?>