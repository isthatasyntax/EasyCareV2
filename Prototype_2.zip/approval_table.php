<?php

    // Connect to server/database
    include("connection.php");

    $sql = "SELECT * FROM absence_log ORDER BY Carer";
    $result = $conn -> query ($sql);
    $info = $result ->fetch_fields();  

?>