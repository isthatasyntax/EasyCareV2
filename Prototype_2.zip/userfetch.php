<?php
session_start();

include('connection.php');

// Check if the user is logged in
if (!isset($_SESSION['identity'])) {
    header("Location: index.php");
    exit();
}
$username=$_SESSION['identity'];
// Fetch user data based on session variables
$stmt = $conn->prepare("SELECT Name,Email,DBS_number FROM carer_details where username='$username'");
$stmt->execute();
$stmt_result = $stmt->get_result();

    if ($stmt_result->num_rows > 0) {
        $row = $stmt_result->fetch_assoc();
        $name = $row['Name'];
        $dbsno = $row['DBS_number'];
        $email = $row['Email'];

        $_SESSION['name'] = $name;
    }

// Display the user data or do other operations
echo "Name: $name<br>";
echo "Email: $email<br>";
echo "DBS Number: $dbsno<br>";
?>
