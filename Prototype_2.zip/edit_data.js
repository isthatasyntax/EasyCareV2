let data = [
    {id: 1, name:"Ali",DBS_number:"222134",PhNo:"07852973387", username:"Alikh727",password:"@Khajjouali999",EmergencyNo:"0785287634",Email:"Khajjouali727@gmail.com"}
]

function readAll(){
    var prodata= document.querySelector(".profile")
    var elements="";
    data.map( d => (
        elements += `<h1>Personal Info</h1>

        <h2>Full Name</h2>
        <p>${d.name}</p>

        <h2>DBS Number</h2>
        <p>${d.DBS_number}</p>

        <h2>Phone Number</h2>
        <p>${d.PhNo}</p>

        <h2>Username</h2>
        <p>${d.username}</p>

        <h2>Password</h2>
        <p>${d.password}</p>
        
        <h2>Emergency Number</h2>
        <p>${d.EmergencyNo}</p>
        
        <h2>Email</h2>
        <p>${d.Email}</p>
        <button class="btn" onclick="{edit(${d.id})}">Edit Personal Information</button>`
    ))
    prodata.innerHTML = elements;
}

function edit(id){
    document.querySelector(".container_form").style.display = "block";
    document.querySelector(".btn").style.display = "none";

    var updateObj = data.find(f=> f.id === id);
    document.querySelector(".update_id").value = updateObj.id;
    document.querySelector('.uname').value = updateObj.name;
    document.querySelector('.uDBS_number').value = updateObj.DBS_number;
    document.querySelector('.uPhNo').value = updateObj.PhNo;
    document.querySelector('.uusername').value = updateObj.username;
    document.querySelector('.upassword').value = updateObj.password;
    document.querySelector('.uEmergencyNo').value = updateObj.EmergencyNo;
    document.querySelector('.uEmail').value = updateObj.Email;
}
function update() {
    var id = parseInt(document.querySelector(".update_id").value);
    var name = document.querySelector('.uname').value ;
    var DBS_number = document.querySelector('.uDBS_number').value ;
    var PhNo = document.querySelector('.uPhNo').value;
    var username = document.querySelector('.uusername').value;
    var password = document.querySelector('.upassword').value;
    var EmergencyNo= document.querySelector('.uEmergencyNo').value;
    var Email= document.querySelector('.uEmail').value ;
    var updateObj ={id, name, DBS_number, PhNo, username, password, EmergencyNo, Email};

    var index = data.findIndex(f => f.id === id);
    data[index] = updateObj;

    document.querySelector(".container_form").style.display = "none";
    document.querySelector(".btn").style.display = "block";

    readAll();
}