<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Carer Data</title>
    <link rel="stylesheet" href="editpage.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
    crossorigin="anonymous">
</head>
<body>
    <nav>
        <ul>
            <li><a href="#home"></a></li>
            <li class="topnav">
                <a href="#edit" class="dropbtn"></a>
                <div class="dropdown-content">
                    <a href="#editPatients">Edit Patient Data</a>
                    <a href="#editCarers">Edit Carer Data</a>
                    <a href="#editAppointments">Edit Appointment Data</a>
                </div>
            </li>
        </ul>
    </nav>

    <center><h1>Edit Details</h1></center>

    <div class="form">
        <div class="form-container">
                <form action="submit.php" method="POST">

                    
                    <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">

                    <div class="input-group">
                        <label for="fname">Full Name:</label>
                        <input type="text" class="input-field" name="fname" id="fname" placeholder="Full Name">
                    </div>
                    
                    <div class="input-group">
                        <label for="dbs_num">DBS Number:</label>
                        <input type="text" class="input-field" name="dbs" id="dbs_num" placeholder="DBS Number">
                    </div>
                    
                    <div class="input-group">
                        <label for="phonenum">Phone Number:</label>
                        <input type="text" class="input-field" name="pnum" id="phonenum" placeholder="Phone Number">
                    </div>

                    <div class="input-group">
                        <label for="uname">Username:</label>
                        <input type="text" class="input-field" name="username" id="uname" placeholder="Username">
                    </div>
                    
                    <div class="input-group">
                        <label for="password">Password:</label>
                        <input type="text" class="input-field" name="pword" id="password" placeholder="Password">
                    </div>
                    
                    <div class="input-group">
                        <label for="emergencynum">Emergency Number:</label>
                        <input type="text" class="input-field" name="enum" id="emergencynum" placeholder="Emergency Number">
                    </div>

                    <div class="input-group">
                        <label for="email">Email Address:</label>
                        <input type="text" class="input-field" name="mail" id="email" placeholder="Email Address">
                    </div>

                    <center><input type="submit" class="btn btn-dark" name="submit" id="sub" value="Submit"></center>
                </form>
        </div>
    </div>
</body>
</html>
