<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>

    <link rel="stylesheet" type="text/css" href="css/header.css">
    <link rel="stylesheet" type="text/css" href="css/footer.css">
    <link rel="stylesheet" type="text/css" href="css/body.css">
    <link rel="stylesheet" type="text/css" href="css/images.css">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
    crossorigin="anonymous">
    <link rel="stylesheet" href="pagedesign.css">
   

</head>
<body>
    <!-- This is the header -->
    <header class="head">
    <div class="topnav">
        <a href="carer_page.php">Carers</a>
        <a href="patient_page.php">Patients</a>
        <a href="appointment_page.php">Appointments</a>
        <a href="approval_page.php">Absences</a>
        <a href="index.php">Sign out</a>
    </div>

    <!-- This is displaying the patinet information -->
    <?php
        include 'patient_table.php';
    ?>

    <table border=1 class="table table-striped">
        <thead>
            <tr>
              
                <?php
                foreach($info as $val){
                    echo "<th>".$val->name."</th>";
                }
                ?>

                <th>Delete</th>
                <th>Edit</th>

            </tr>
        </thead>

        <tbody>
            <?php
                while($row = mysqli_fetch_assoc($result)){
                    echo "<tr>";
                    foreach($row as $val){
                        print "<td>". $val. "</td>";
                    }

                    /* Button for deleting and editing a record */
                    echo "<td><a href='delete1.php?id=" . $row['Patient_ID'] . "'><button>Delete</button></a></td>";  
                    echo "<td><a href='edit1.php?id=" . $row['Patient_ID'] . "'><button>Edit</button></a></td>";  
                    echo "</tr>";
                }  
            ?>
        </tbody>
        <center><a href="add_page1.php"><button>Add Patient</button></a></center>
    </table>
    


    <footer>
        <div>
            <img class="logo" src="logo.png" alt="Easy Care" title="Logo"><br>
            <p>Contact Us:</p>
            <p>Email: EasyCare@gmail.co.uk | Phone: +44 20 1234 5678</p>
            <p>&copy; 2024. All rights reserved.</p>
        </div>
    </footer>
     
</body>
</html>