<?php
include ("connection.php");

if (isset ($_POST["submit"])) {
    // Retrieve form data
    $fname = $_POST["fname"];
    $address = $_POST["addr"];
    $postcode = $_POST["pcode"];
    $meds = $_POST["med_det"];
    $patientID = $_POST["pid"];
    $birth = $_POST["dob"];
    $sex = $_POST["sx"];
    $phoneN = $_POST["pnum"];
    $d_fname = $_POST["dname"];
    $d_address = $_POST["daddress"];
    $nok_fname = $_POST["nokName"];
    $nok_phone = $_POST["nok_num"];

    // Update database
    $sql = "INSERT INTO patient_details  (name, address, postcode, medication_details, patient_ID, DOB, gender, phonenumber, doctor_name, doctor_address, nok_name, nok_PhNo) VALUES ('$fname', '$address', '$postcode', '$meds', '$patientID', '$birth', '$sex', '$phoneN', '$d_fname', '$d_address', '$nok_fname', '$nok_phone')";
    
    if (mysqli_query($conn, $sql)) {
        header("location: patient_page.php");
    } else {
        header("location: edit1.php");
    }
}
?>