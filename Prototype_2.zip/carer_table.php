<?php
    // Connect to server/database
    include("connection.php");
    
    $sql = "SELECT * FROM carer_details ORDER BY Name";
    $result = $conn -> query ($sql);
    $info = $result ->fetch_fields();    
?>