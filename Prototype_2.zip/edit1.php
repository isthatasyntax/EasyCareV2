<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Form</title>
    <link rel="stylesheet" href="editpatient.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
    crossorigin="anonymous">
</head>
<body>

    <nav>
        <ul>
            <li><a href="#home"></a></li>
            <li class="topnav">
                <a href="#edit" class="dropbtn"></a>
                <div class="dropdown-content">
                    <a href="#editPatients">Edit Patient Data</a>
                    <a href="#editCarers">Edit Carer Data</a>
                    <a href="#editAppointments">Edit Appointment Data</a>
                </div>
            </li>
        </ul>
    </nav>
    
    <h1>Edit Details</h1>

    <div class="form">
        <div class="form-container">
                <form action="submit1.php" method="POST">
                    <center>
                    <!-- Allows to use the id, without the user seeing it -->
                    <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">

                    <div class="input-group">
                        <label for="name">Name:</label><br>
                        <input type="text" class="" name="fname" id="name" placeholder="Full Name">
                    </div>
                    
                    <br>

                    <div class="input-group">
                        <label for="address">Address:</label><br>
                        <input type="text" class="" name="addr" id="address" placeholder="Address">
                    </div>
                    
                    <br>

                    <div class="input-group">
                        <label for="postcode">Postcode:</label><br>
                        <input type="text" class="" name="pcode" id="postcode" placeholder="Postcode">
                    </div>

                    <br>

                    <div class="input-group">
                        <label for="medication_det">Medication Details</label><br>
                        <input type="text" class="" name="med_det" id="medication_det" placeholder="Medication Details">
                    </div>
                    
                    <br>

                    <div class="input-group">
                        <label for="patient_ID">Patient ID</label><br>
                        <input type="text" class="" name="pid" id="patient_ID" placeholder="Patient ID">
                    </div>
                    
                    <br>

                    <div class="input-group">
                        <label for="DOB">Date of birth</label><br>
                        <input type="text" class="" name="dob" id="DOB" placeholder="Date Of Birth">
                    </div>

                    <br>

                    <div class="input-group">
                        <label for="gender">Gender</label><br>
                        <input type="text" class="" name="sx" id="gender" placeholder="Gender">
                    </div>

                    <br>

                    <div class="input-group">
                        <label for="phonenumber">Phone Number</label><br>
                        <input type="text" class="" name="pnum" id="phonenumber" placeholder="Phone Number">
                    </div>

                    <br>

                    <div class="input-group">
                        <label for="doctor_name">Doctors Name</label><br>
                        <input type="text" class="" name="dname" id="doctor_name" placeholder="Gender">
                    </div>
                    
                    <br>

                    
                    <div class="input-group">
                        <label for="doctor_address">Doctors Address</label><br>
                        <input type="text" class="" name="daddress" id="doctor_address" placeholder="Doctor Address">
                    </div>
                    
                    <br>

                    <div class="input-group">
                        <label for="nok_name">Next of Kin:</label><br>
                        <input type="text" class="" name="nokName" id="nok_name" placeholder="Next Of Kin Name">
                    </div>
                    
                    <br>

                    <div class="input-group">
                        <label for="nok_PhNo">Next of Kin number:</label><br>
                        <input type="text" class="" name="nok_num" id="nok_PhNo" placeholder="Next Of Kin Phone Number">
                    </div>

                    <input type="submit" name="submit" id="sub" value="Submit"></center>
                </form>
        </div>
    </div>


            

</body>
</html>