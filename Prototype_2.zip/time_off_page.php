<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="time_off_page_stylesheet.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet"
        class="roboto-slab-font">

    <title>Schedule</title>
</head>

<body>
   <!--Navigation Bar-->
    <div class="topnav">
        <a href="home_page_4.html">
            <div class="icon-container">
                <svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 24 24"
                    class="icon">
                    <title>Home</title>
                    <path
                        d="M22.017,5.831l-1.017-.686V1.5c0-.276-.224-.5-.5-.5s-.5,.224-.5,.5v2.97L14.517,.77c-1.529-1.032-3.506-1.031-5.033,0L1.983,5.831c-1.242,.837-1.983,2.232-1.983,3.73v9.939c0,2.481,2.019,4.5,4.5,4.5h3c.276,0,.5-.224,.5-.5V14.5c0-.827,.673-1.5,1.5-1.5h5c.827,0,1.5,.673,1.5,1.5v9c0,.276,.224,.5,.5,.5h3c2.481,0,4.5-2.019,4.5-4.5V9.561c0-1.499-.741-2.893-1.983-3.73Zm.983,13.669c0,1.93-1.57,3.5-3.5,3.5h-2.5V14.5c0-1.378-1.121-2.5-2.5-2.5h-5c-1.379,0-2.5,1.122-2.5,2.5v8.5h-2.5c-1.93,0-3.5-1.57-3.5-3.5V9.561c0-1.166,.576-2.25,1.542-2.901L10.042,1.599c1.189-.803,2.727-.803,3.916,0l7.5,5.061c.966,.651,1.542,1.736,1.542,2.901v9.939Z" />
                </svg>
            </div>
        </a>
        <a href="schedule_page_4.html">
            <div class="icon-container">
                <svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 24 24"
                    class="icon">
                    <title>Schedule</title>
                    <path
                        d="M19.5,2h-1.5V.5c0-.28-.22-.5-.5-.5s-.5,.22-.5,.5v1.5H7V.5c0-.28-.22-.5-.5-.5s-.5,.22-.5,.5v1.5h-1.5C2.02,2,0,4.02,0,6.5v13c0,2.48,2.02,4.5,4.5,4.5h15c2.48,0,4.5-2.02,4.5-4.5V6.5c0-2.48-2.02-4.5-4.5-4.5Zm-8,7v4H7v-4h4.5Zm5.5,0v4h-4.5v-4h4.5Zm6,0v4h-5v-4h5ZM6,13H1v-4H6v4Zm-5,1H6v4H1v-4Zm6,0h4.5v4H7v-4Zm4.5,5v4H7v-4h4.5Zm1,0h4.5v4h-4.5v-4Zm0-1v-4h4.5v4h-4.5Zm5.5-4h5v4h-5v-4ZM4.5,3h15c1.93,0,3.5,1.57,3.5,3.5v1.5H1v-1.5c0-1.93,1.57-3.5,3.5-3.5ZM1,19.5v-.5H6v4h-1.5c-1.93,0-3.5-1.57-3.5-3.5Zm18.5,3.5h-1.5v-4h5v.5c0,1.93-1.57,3.5-3.5,3.5Z" />
                </svg>
            </div>
        </a>
        <div class="dropdown">
            <button class="dropbtn">
                <div class="icon-container">
                    <svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 24 24"
                        class="icon">
                        <title>User</title>
                        <path
                            d="m12,0C5.383,0,0,5.383,0,12s5.383,12,12,12,12-5.383,12-12S18.617,0,12,0Zm-5,21.797v-3.297c0-.827.673-1.5,1.5-1.5h7c.827,0,1.5.673,1.5,1.5v3.297c-1.501.769-3.201,1.203-5,1.203s-3.499-.434-5-1.203Zm11-.582v-2.715c0-1.379-1.122-2.5-2.5-2.5h-7c-1.378,0-2.5,1.121-2.5,2.5v2.715c-3.008-1.965-5-5.362-5-9.215C1,5.935,5.935,1,12,1s11,4.935,11,11c0,3.853-1.992,7.25-5,9.215Zm-6-15.215c-2.206,0-4,1.794-4,4s1.794,4,4,4,4-1.794,4-4-1.794-4-4-4Zm0,7c-1.654,0-3-1.346-3-3s1.346-3,3-3,3,1.346,3,3-1.346,3-3,3Z" />
                    </svg>
                </div>
            </button>
            <div class="dropdown-content">
                <a href="my_profile_page.php">My Profile</a>
                <a href="help_page.html">Help</a>
                <a href="time_off_page.php">Time Off</a>
                <a href="index.php">Sign Out</a>
            </div>
        </div>
    </div>
    <div class="container">
        <form >
            <h1>Request Leave</h1>
            <h2>Leave type</h2>
            <div class="select">
                <select name="format" id="format">
                    <option selected disabled>Choose leave type</option>
                    <option value="Vacation">Vacation</option>
                    <option value="Personal">Personal</option>
                    <option value="Sick">Sick</option>
                </select>
            </div>
            <input type="date" id="From" placeholder="From" required="">
            <input type="date" id="To" placeholder="To" required="">
            <h4>Reason for Leave...</h4>
            <textarea required=""></textarea>
            <input type="submit" value="Submit" id="button" name="submit">
        </form>
    </div>

    <footer>
        <div class="footer-content-container">
                <img class="logo" src="logo.png" alt="Easy Care" title="Logo" style="width: 60px; height: 60px;"><br>
                <a href="home_page_4.html">Home</a>
                <a href="about_us_page.html">About Us</a>
                <a href="help_page.html">Help</a>
                <a href="help_page.html">Policies</a>
                <a href="time_off_page.php">Time Off</a>
                <p><br></p>
                <p>Contact Us:</p>
                <p>Email: PatientPortalPrivacy@gmail.com | Phone: +447395853930</p>
                <p>&copy; 2024. All rights reserved.</p>
        </div>
    
    </footer>
</body>

</html>