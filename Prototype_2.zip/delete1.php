<?php
    include("connection.php");

    if (isset($_GET["id"])) { 
        $id = $_GET["id"];
    
    $sql = "DELETE FROM patient_details WHERE id=$id";
    $conn->query($sql);
    }

    header("Location: patient_page.php");
    exit;
?>