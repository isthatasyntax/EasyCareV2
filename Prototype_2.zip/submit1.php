<?php
include ("connection.php");

if (isset ($_POST["submit1"])) {
    // Retrieve form data
    $id = $_POST['id'];
    $fname = $_POST["fname"];
    $address = $_POST["addr"];
    $postcode = $_POST["pcode"];
    $meds = $_POST["med_det"];
    $patientID = $_POST["pid"];
    $birth = $_POST["dob"];
    $sex = $_POST["sx"];
    $phoneN = $_POST["pnum"];
    $d_fname = $_POST["dname"];
    $d_address = $_POST["daddress"];
    $nok_fname = $_POST["nokName"];
    $nok_phone = $_POST["nok_num"];

    // Update database
    $sql = "UPDATE patient_details SET name='$fname', address='$address', postcode='$postcode', medication_details='$meds', patient_ID='$patientID', DOB='$birth', gender='$sex', phonenumber='$phoneN', doctor_name='$d_fname', doctor_address='$d_address', nok_name='$nok_fname', nok_PhNo='$nok_phone' WHERE id='$id'";
    if (mysqli_query($conn, $sql)) {
        header("location: patient_page.php");
    } else {
        header("location: edit1.php");
    }
}
?>