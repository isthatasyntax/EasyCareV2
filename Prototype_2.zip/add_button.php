<?php
include ("connection.php");

if (isset ($_POST["submit"])) {
    // Retrieve form data
    $fname = $_POST["fname"];
    $dbs = $_POST["dbs"];
    $pnum = $_POST["pnum"];
    $username = $_POST["username"];
    $pword = $_POST["pword"];
    $enum = $_POST["enum"];
    $mail = $_POST["mail"];

    // Update database
    $sql = "INSERT INTO carer_details (Name, DBS_number, PhNo, username, password, EmergencyNo, Email) VALUES ('$fname', '$dbs', '$pnum', '$username', '$pword', '$enum', '$mail')";
    if (mysqli_query($conn, $sql)) {
        header("location: carer_page.php");
    } else {
        header("location: edit.php");
    }
}
?>