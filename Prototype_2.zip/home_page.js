// Made By Schinda

function changeGreeting() {
    var hour = new Date().getHours();
    var greeting;

    if (hour >= 5 && hour < 12) {
        greeting = "Good morning!";
    } else if (hour >= 12 && hour < 17) {
        greeting = "Good afternoon!";
    } else if (hour >= 17 && hour < 21) {
        greeting = "Good evening!";
    } else {
        greeting = "Good night!";
    }

    greeting
    var randomGreeting = Math.random() < 0.5 ? greeting : getRandomDefaultGreeting();

    document.getElementById("greeting").innerHTML = randomGreeting;
}

function getRandomDefaultGreeting() {
    var defaultGreetings = ["Hello there!", "Welcome!", "Greetings!"];
    return defaultGreetings[Math.floor(Math.random() * defaultGreetings.length)];
}

window.onload = function () {
    getRandomDefaultGreeting();
    changeGreeting();
};

// Made By Nishka

document.addEventListener("DOMContentLoaded", function () {
    console.log("DOM loaded. Generating schedule...");
    generatePage();
})

//code to generate the appointment box
//exactly the same as the schedule page
async function generatePage() {
    const weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const d = new Date();
    let day = weekday[d.getDay()];

    var main = document.getElementById("main");

    var asideLeft = document.createElement("div");
    asideLeft.className = "asideleft";
    var greeting = document.createElement("h1");
    greeting.id = "greeting";
    greeting.innerHTML = "Welcome";
    asideLeft.appendChild(greeting);
    main.appendChild(asideLeft);

    var h2 = document.createElement("h2");
    h2.innerHTML = "Your appointments for today:";
    main.appendChild(h2);

    console.log("Generating schedule...");
    var idNum = 1;
    var main = document.getElementById("main");

    console.log("Fetching appointment data...");
    const appointmentRes = await fetch("homepagedata.php");
    const appointmentText = await appointmentRes.text();
    console.log("Fetched appointment data:", appointmentText);


    const appointmentData = JSON.parse(appointmentText);
    console.log("Parsed appointment data:", appointmentData);

    console.log("Fetching patient data...");
    const patientRes = await fetch("patientdetail.php");
    const patientText = await patientRes.text();
    console.log("Fetched appointment data:", patientText);

    const patientData = JSON.parse(patientText);
    console.log("Parsed appointment data:", patientData);

    // Group appointments by date
    const appointmentsByDate = {};
    appointmentData.forEach(appointment => {
        const date = appointment.Date;
        if (!appointmentsByDate[date]) {
            appointmentsByDate[date] = [];
        }
        appointmentsByDate[date].push(appointment);
    });

    // Loop through each date and generate appointment divs
    Object.keys(appointmentsByDate).forEach(date => {
        const day = new Date(date).toLocaleDateString('en-US', { weekday: 'long' });
        console.log(`Generating appointments for ${day} (${date})...`);
        var heading = document.createElement("h3");
        heading.innerHTML = `${day} ${date}`;
        main.appendChild(heading);
        idNum = generateDiv(day, idNum, appointmentsByDate[date], patientData);
    });


    var h3 = document.createElement("h3");
    h3.className = "important-header";
    h3.innerHTML = "Important Resource Links";
    main.appendChild(h3);

    var div = document.createElement("div");
    div.className = "link-container";

    var linkBox1 = document.createElement("div");
    linkBox1.className = "link-box";
    var link1 = document.createElement("a");
    link1.href = "https://www.nhs.uk/conditions/first-aid/";
    link1.innerHTML = "First Aid Resources";
    linkBox1.appendChild(link1);
    div.appendChild(linkBox1);

    var linkBox2 = document.createElement("div");
    linkBox2.className = "link-box";
    var link2 = document.createElement("a");
    link2.href = "https://www.nhs.uk/conditions/sepsis/";
    link2.innerHTML = "Signs of Sepsis";
    linkBox2.appendChild(link2);
    div.appendChild(linkBox2);

    main.appendChild(div);
}
function generateDiv(day, idNum, appointments, patientData) {
    console.log(`Generating divs for ${day}...`);

    var main = document.getElementById("main");

    appointments.forEach(appointment => {
        console.log("Creating appointment div...");
        // Create appointment div
        var div1 = document.createElement("div");
        div1.id = "appointment" + idNum;
        div1.className = "appointment";


        var div2 = document.createElement("div");
        div2.id = "time" + idNum;
        div2.className = "time";
        var p1 = document.createElement("p");
        p1.innerHTML = `${appointment.Start_Time} - <br> ${appointment.End_Time}`; // Use appointment start and end times
        div2.appendChild(p1);
        div1.appendChild(div2);


        var div3 = document.createElement("div");
        div3.id = "details" + idNum;
        div3.className = "details";


        var p2 = document.createElement("p");
        p2.id = "text" + idNum;
        p2.className = "text";
        var span = document.createElement("span");
        span.id = "moreText" + idNum;
        span.className = "more-text";
        var patient = appointment.Patient || "Unknown";
        var location = appointment.location || "Unknown";

        span.innerHTML = `<b>Patient dob:</b> ${patientData.dob} <br> <b>Gender:</b> ${patientData.gender} <br> <b>Doctor's name:</b> ${patientData.doctor_name} <br> <b>Doctor's Address:</b> ${patientData.doctor_address} <br> <b>Next of Kin:</b> ${patientData.nok_name} <br> <b>Next of Kin Ph:</b> ${patientData.nok_phno} <br>`;
        p2.innerHTML = `<b>Patient Name:</b> ${patient}  <br> <b>Medication Details:</b> ${patientData.medication_details} <br> <b>Address:</b> ${location} <br> <b>Patient PhoneNumber:</b> ${patientData.phonenumber} <br> `;


        p2.appendChild(span);
        div3.appendChild(p2);

        // Create button container
        var div4 = document.createElement("div");
        div4.id = "button-container" + idNum;
        div4.className = "button-container";


        var button1 = document.createElement("button");
        button1.id = "readMoreButton" + idNum;
        button1.className = "more-details-btn";
        button1.innerHTML = "More Details";
        div4.appendChild(button1);


        var button2 = document.createElement("button");
        button2.id = "callPatientButton" + idNum;
        button2.className = "call-btn";
        button2.innerHTML = "Call Patient";
        div4.appendChild(button2);


        var button3 = document.createElement("button");
        button3.id = "absentButton" + idNum;
        button3.className = "absent-btn";
        button3.innerHTML = "Can't make it?";
        div4.appendChild(button3);

        div3.appendChild(div4);
        div1.appendChild(div3);
        main.appendChild(div1);

        console.log("Appointment:", appointment);
        idNum++;
    });

    var call_btns = document.querySelectorAll(".absent-btn");

    call_btns.forEach(function (button) {
        button.addEventListener("click", timeoff);
    });

    var more_details_btns = document.querySelectorAll(".more-details-btn");

    more_details_btns.forEach(function (button) {
        button.addEventListener("click", openMoreDetails);
    });

    var call_btns = document.querySelectorAll(".call-btn");

    call_btns.forEach(function (button) {
        button.addEventListener("click", callPatient);
    });

    console.log(`Generated divs for ${day}.`);
    return idNum;
}

function openMoreDetails() {

    let matches = this.id.match(/(\d+)/);
    var idNum = matches[0];
    var moreText = document.getElementById("moreText" + idNum);

    if (moreText.style.display === "inline") {
        this.innerHTML = "More Details";
        moreText.style.display = "none";
    }
    else {
        this.innerHTML = "Show Less";
        moreText.style.display = "inline";
    }
}

function callPatient() {
    // Replace number with patients phone number
    //this feature will only work on a device capable of making phone calls
    window.location.href = "tel:+447918383931";
}

function timeoff() {
    window.location.href = "time_off_page.php";
}
