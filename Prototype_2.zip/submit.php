<?php
include ("connection.php");

if (isset ($_POST["submit"])) {
    // Retrieve form data
    $id = $_POST['id'];
    $fname = $_POST["fname"];
    $dbs = $_POST["dbs"];
    $pnum = $_POST["pnum"];
    $username = $_POST["username"];
    $pword = $_POST["pword"];
    $enum = $_POST["enum"];
    $mail = $_POST["mail"];

    // Update database
    $sql = "UPDATE carer_details SET Name='$fname', DBS_number='$dbs', PhNo='$pnum', username='$username', password='$pword', EmergencyNo='$enum', Email='$mail' WHERE id='$id'";
    if (mysqli_query($conn, $sql)) {
        header("location: carer_page.php");
    } else {
        header("location: edit.php");
    }
}
?>