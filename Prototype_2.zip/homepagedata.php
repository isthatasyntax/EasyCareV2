<?php
    session_start();
    include('connection.php');
    
    $currentDate = date('Y-m-d');

    $name = $_SESSION['name'];
    
    //$name="Grace Taylor";
    $stmt = $conn->prepare("SELECT Date, Day, Start_Time, End_Time, Location, Patient, Carer FROM appointment_details WHERE Carer=? AND Date=?");
    $stmt->bind_param("ss", $name, $currentDate);
    $stmt->execute();
    $stmt_result = $stmt->get_result();

   
    $appointments = [];

    
    if ($stmt_result->num_rows > 0) {
        
        while ($row = $stmt_result->fetch_assoc()) {
            $_SESSION['patientname'] = $row['Patient'];

            $appointments[] = [
                'Date' => $row['Date'],
                'Day' => $row['Day'],
                'Start_Time' => $row['Start_Time'],
                'End_Time' => $row['End_Time'],
                'location' => $row['Location'],
                'Patient' => $row['Patient'],
                'Carer' => $row['Carer']

            ];
        }
    }

    
    echo json_encode($appointments);

    
    $stmt->close();
    $conn->close();


?>