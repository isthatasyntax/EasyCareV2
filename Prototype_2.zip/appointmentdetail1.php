<?php

    /*include('connection.php');
    include('sql_login.php');
    $currentDate = date('Y-m-d');

    $startOfWeek = date('Y-m-d', strtotime('last Monday', strtotime($currentDate)));
    $endOfWeek = date('Y-m-d', strtotime('next Sunday', strtotime($currentDate)));


    $stmt = $conn->prepare("SELECT Date,Day,Start_Time,End_Time,Location,Patient,Carer FROM appointment_details where Date=$currentdate");
    $stmt->execute();
    $stmt_result = $stmt->get_result();

    if ($stmt_result->num_rows > 0) {
        $row = $stmt_result->fetch_assoc();
        $date = $row['Date'];
        $day = $row['Day'];
        $start_time = $row['Start_Time'];
        $end_time = $row ['End_Time'];
        $Location = $row['Location'];
        $Patient = $row['Patient'];
        $carer = $row['Carer'];
    }*/

    session_start();
    include('connection.php');
    

    $currentDate = date('Y-m-d');

    $startOfWeek = date('Y-m-d', strtotime('last Monday', strtotime($currentDate)));
    $endOfWeek = date('Y-m-d', strtotime('next Sunday', strtotime($currentDate)));

    $name = $_SESSION['name'];
    
    //$name="Grace Taylor";
    $stmt = $conn->prepare("SELECT Date,Day,Start_Time,End_Time,Location,Patient,Carer FROM appointment_details WHERE Carer=? AND Date BETWEEN ? AND ?");
    $stmt->bind_param("sss", $name,$startOfWeek, $endOfWeek);
    $stmt->execute();
    $stmt_result = $stmt->get_result();

   
    $appointments = [];

    
    if ($stmt_result->num_rows > 0) {
        
        while ($row = $stmt_result->fetch_assoc()) {
            $_SESSION['patientname'] = $row['Patient'];

            $appointments[] = [
                'Date' => $row['Date'],
                'Day' => $row['Day'],
                'Start_Time' => $row['Start_Time'],
                'End_Time' => $row['End_Time'],
                'location' => $row['Location'],
                'Patient' => $row['Patient'],
                'Carer' => $row['Carer']

            ];
        }
    }

    
    echo json_encode($appointments);

    
    $stmt->close();
    $conn->close();


?>