// Made by Nishka

document.addEventListener("DOMContentLoaded", function () {
    generateSchedule();
});

function generateDiv(day, idNum) {

    //get number of rows from database here
    //day variable contains the name of the day if it's helpful
    var rowNums = 1;

    var main = document.getElementById("main");

    if (rowNums > 0) {

        for (i = 0; i < rowNums; i++) {

            //creating big appointment div
            var div1 = document.createElement("div");
            div1.id = "appointment" + idNum;
            div1.className = "appointment";

            //create time div
            var div2 = document.createElement("div");
            div2.id = "time" + idNum;
            div2.className = "time";
            var p1 = document.createElement("p");
            p1.innerHTML = "*start time* - <br> *end time*";
            div2.appendChild(p1);
            div1.appendChild(div2);

            //create details div
            var div3 = document.createElement("div");
            div3.id = "details" + idNum;
            div3.className = "details";

            //text
            var p2 = document.createElement("p");
            p2.id = "text" + idNum;
            p2.className = "text";
            var span = document.createElement("span");
            span.id = "moreText" + idNum;
            span.className = "more-text";
            const test = `${idNum} aisaskksksks`;
            span.innerHTML = "*patient ID* <br> *patient phone number* <br> *patient date of birth* <br> *patient gender* <br> *next of kin name* <br> *next of kin phone number* <br> *doctor name* <br> *doctor address* <br>";
            p2.innerHTML = "*patient name* <br> *patient address*, *postcode*<br>";
            p2.appendChild(span);
            div3.appendChild(p2);

            //button container
            var div4 = document.createElement("div");
            div4.id = "button-container" + idNum;
            div4.className = "button-container";

            //read more button
            var button1 = document.createElement("button");
            button1.id = "readMoreButton" + idNum;
            button1.className = "more-details-btn";
            button1.innerHTML = "More Details";
            div4.appendChild(button1);

            //call patient button
            var button2 = document.createElement("button");
            button2.id = "callPatientButton" + idNum;
            button2.className = "call-btn";
            button2.innerHTML = "Call Patient";
            div4.appendChild(button2);

            //absent button
            var button3 = document.createElement("button");
            button3.id = "absentButton" + idNum;
            button3.className = "absent-btn";
            button3.innerHTML = "Can't make it?";
            div4.appendChild(button3);

            div3.appendChild(div4);

            div1.appendChild(div3);

            //append whole thing onto the main div
            main.appendChild(div1);

            idNum++;
        }
        return idNum;

    }
    else {

        //creating no appointment div
        var div1 = document.createElement("div");
        div1.className = "no-appointment";
        var p1 = document.createElement("p");
        p1.innerHTML = "No appointments";
        div1.appendChild(p1);

        //append whole thing onto the body
        main.appendChild(div1);

    }
}

async function generateSchedule() {

    var idNum = 1;

    var main = document.getElementById("main");

    const res = await fetch("appointmentdetail1.php");
    const data = await res.json();
    console.log(data);
    //create h3 heading
    var monday = document.createElement("h3");
    monday.innerHTML = "Monday *date* *month*";
    main.appendChild(monday);

    //call function to generate divs
    idNum = generateDiv(day = "Monday", idNum);

    var tuesday = document.createElement("h3");
    tuesday.innerHTML = "Tuesday *date* *month*";
    main.appendChild(tuesday);

    idNum = generateDiv(day = "Tuesday", idNum);

    var wednesday = document.createElement("h3");
    wednesday.innerHTML = "Wednesday *date* *month*";
    main.appendChild(wednesday);

    idNum = generateDiv(day = "Wednesday", idNum);

    var thursday = document.createElement("h3");
    thursday.innerHTML = "Thursday *date* *month*";
    main.appendChild(thursday);

    idNum = generateDiv(day = "Thursday", idNum);

    var friday = document.createElement("h3");
    friday.innerHTML = "Friday *date* *month*";
    main.appendChild(friday);

    idNum = generateDiv(day = "Friday", idNum);

    var saturday = document.createElement("h3");
    saturday.innerHTML = "Saturday *date* *month*";
    main.appendChild(saturday);

    idNum = generateDiv(day = "Saturday", idNum);

    var sunday = document.createElement("h3");
    sunday.innerHTML = "Sunday *date* *month*";
    main.appendChild(sunday);

    idNum = generateDiv(day = "Sunday", idNum);

    //more details buttons
    var more_details_btns = document.querySelectorAll(".more-details-btn");

    more_details_btns.forEach(function (button) {
        button.addEventListener("click", openMoreDetails);
    });

    //call patient buttons
    var call_btns = document.querySelectorAll(".call-btn");

    call_btns.forEach(function (button) {
        button.addEventListener("click", callPatient);
    });

}

//function to show more details about appointment
function openMoreDetails() {

    let matches = this.id.match(/(\d+)/);
    var idNum = matches[0];
    var moreText = document.getElementById("moreText" + idNum);

    if (moreText.style.display === "inline") {
        this.innerHTML = "More Details";
        moreText.style.display = "none";
    }
    else {
        this.innerHTML = "Show Less";
        moreText.style.display = "inline";
    }
}

//call patient when button is clicked
function callPatient() {
    // Replace number with patients phone number
    //this feature will only work on a device capable of making phone calls
    window.location.href = "tel:+447918383931";
}