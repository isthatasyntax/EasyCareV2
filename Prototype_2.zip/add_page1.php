<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Patient</title>
</head>
<body>
    
    <h1>Add Patient</h1>

    <div class="">
        <div class="">
                <form action="add_button1.php" method="POST">

                    <div class="">
                        <label for="name"></label>
                        <input type="text" class="" name="fname" id="name" placeholder="Full Name">
                    </div>
                    
                    <br>

                    <div class="">
                        <label for="address"></label>
                        <input type="text" class="" name="addr" id="address" placeholder="Address">
                    </div>
                    
                    <br>

                    <div class="">
                        <label for="postcode"></label>
                        <input type="text" class="" name="pcode" id="postcode" placeholder="Postcode">
                    </div>

                    <br>

                    <div class="">
                        <label for="medication_det"></label>
                        <input type="text" class="" name="med_det" id="medication_det" placeholder="Medication Details">
                    </div>
                    
                    <br>

                    <div class="">
                        <label for="patient_ID"></label>
                        <input type="text" class="" name="pid" id="patient_ID" placeholder="Patient ID">
                    </div>
                    
                    <br>

                    <div class="">
                        <label for="DOB"></label>
                        <input type="text" class="" name="dob" id="DOB" placeholder="Date Of Birth">
                    </div>

                    <br>

                    <div class="">
                        <label for="gender"></label>
                        <input type="text" class="" name="sx" id="gender" placeholder="Gender">
                    </div>

                    <br>

                    <div class="">
                        <label for="phonenumber"></label>
                        <input type="text" class="" name="pnum" id="phonenumber" placeholder="Phone Number">
                    </div>

                    <br>

                    <div class="">
                        <label for="doctor_name"></label>
                        <input type="text" class="" name="dname" id="doctor_name" placeholder="Doctor Name">
                    </div>
                    
                    <br>

                    
                    <div class="">
                        <label for="doctor_address"></label>
                        <input type="text" class="" name="daddress" id="doctor_address" placeholder="Doctor Address">
                    </div>
                    
                    <br>

                    <div class="">
                        <label for="nok_name"></label>
                        <input type="text" class="" name="nokName" id="nok_name" placeholder="Next Of Kin Name">
                    </div>
                    
                    <br>

                    <div class="">
                        <label for="nok_PhNo"></label>
                        <input type="text" class="" name="nok_num" id="nok_PhNo" placeholder="Next Of Kin Phone Number">
                    </div>

                    <input type="submit" name="submit" id="sub" value="Submit">
                </form>
        </div>
    </div>


            

</body>
</html>